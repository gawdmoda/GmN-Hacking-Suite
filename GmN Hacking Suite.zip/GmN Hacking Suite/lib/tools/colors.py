from colorama import Fore, init, Style, Back

init(autoreset=True)
r = Fore.RED + Style.BRIGHT
g = Fore.GREEN + Style.BRIGHT
c = Fore.CYAN + Style.BRIGHT
y = Fore.YELLOW + Style.BRIGHT
o = Fore.RESET + Style.RESET_ALL
wh = Fore.WHITE + Style.BRIGHT
y = Fore.YELLOW
yl = Fore.YELLOW
res = Style.RESET_ALL
blc = Fore.BLACK
bg_gr = Back.GREEN
bg_red = Back.RED
bg_wh = Back.WHITE
bg_y = Back.YELLOW
red = Fore.RED
green = Fore.GREEN
res = Fore.RESET
rst = Back.RESET
